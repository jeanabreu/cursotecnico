from openerp.osv import osv,fields
class openacademy_course(osv.Model):
    _name = "openacademy.course"
    _columns = {
            'name': fields.char('Name',32,required=True),
            'description' : fields.text('Description'),
            'session_ids' : fields.one2many('openacademy.session','course_id', string='Sessions'),
            'responsible_id': fields.many2one('res.users',string='Responsible'),            
        } 
class openacademy_session(osv.Model):
    _name = "openacademy.session"
    _columns = {
            'name': fields.char('Name',32,required=True),
            'duration' : fields.float('Duration'),
            'seats' : fields.integer('Seats'),
            'startdate' : fields.date('Start Date'),
            'course_id' : fields.many2one('openacademy.course',string='Course'),
            'atendee_ids': fields.one2many('openacademy.atendee','session_id',string='Atendees'),
            'instructor_id': fields.many2one('res.partner', string='Instructor',
                                             domain = ['|',('is_instructor','=',True),('category_id.name','in',['Instructor Nivel I','Instructor Nivel II'])]),
            
        } 
class openacademy_atendee(osv.Model):
    _name = "openacademy.atendee"
    _columns = {
            'name': fields.char('Name',32, required=True),
            'session_id': fields.many2one('openacademy.session',string='Session'),
            'partner_id': fields.many2one('res.partner', string='Partner'),

        } 
